#!/bin/bash
set -e

printf '\033[34;5m
         888                                            d8b 888
         888                                            Y8P 888
         888                                                888
 .d8888b 888  .d88b.  88888b.   .d88b.         .d8888b  888 888888 .d88b.
d88P    888 d88**88b 888 \"88b d8P  Y8b        88K      888 888   d8P  Y8b
888      888 888  888 888  888 88888888        Y8888b. 888 888   88888888
Y88b.    888 Y88..88P 888  888 Y8b.                 X88 888 Y88b. Y8b.
 \"Y8888P 888  \"Y88P"  888  888  Y8888 88888888 88888P 888  Y888 Y8888
\033[0m\n
  '

show_usage() {
  echo
  echo "Usage: $(basename $0) [-c provided|pem|certbot] [-d DOMAIN] [-i CLONE_SITE] [-u username] [-p 'password' ] [-k ssh_key] [-s ssh_port]"
  echo "   Default value for -c is 'certbot'."
  echo "   Default value for -u is 'root'"
  echo "   Default value for -s is '22'."
  echo
  echo "      ex.1: $(basename $0) -d example.local -i 192.168.10.10 -p 'Password!123' -s 22"
  echo "      ex.2: $(basename $0) -c pem -d example.local -i 192.168.10.10 -k id_rsa -s 22"
  echo "      ex.3: $(basename $0) -c pem -d example.local -i 192.168.10.10 -k id_rsa -s 22 -r update"
  exit 0
}

while getopts ":c:d:i:u:p:k:s:" OPT; do
  case ${OPT} in
  d)
    DOMAIN="${OPTARG}"
    ;;
  c)
    PEM_FILE="${OPTARG}"
    ;;
  i)
    CLONE_SITE="${OPTARG}"
    ;;
  u)
    VPS_USER="${OPTARG}"
    ;;
  p)
    PASS="${OPTARG}"
    ;;
  k)
    KEY_NAME="${OPTARG}"
    ;;
  s)
    SSH_PORT="${OPTARG}"
    ;;
  h)
    show_usage
    exit 0
    ;;
  \?)
    echo -e "\033[0;31m Invalid option \033[1;97m"
    show_usage
    exit 1
    ;;
  esac
done

EXEC_DIR=$(pwd)
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export DOCKER_CONTENT_TRUST=1
export DEBIAN_FRONTEND="noninteractive"

NGINX_CERTS_DIR="/var/nginx/certificates"
NGINX_CONFIG_DIR="/var/nginx/config"
NGINX_INDEX_DIR="/var/nginx/config/website"
NGINX_LOG_DIR="/var/log/nginx"


create_certs(){
echo "[*] Unzip certs"
unzip -q ${DOMAIN/./_}.zip -d ${DOMAIN}/

echo "[*} Rename cert files"
cd ${DOMAIN}
mv *.ca-bundle chain.pem
mv *.crt fullchain.pem
mv *.txt privkey.pem
rm *.p7b

echo "[*] Append chain to fullchain.pem file"
END_CERT_LINE=$(grep -n "END CERTIFICATE" chain.pem | head -n 1 | cut -d":" -f 1)
echo >> fullchain.pem
cat chain.pem >> fullchain.pem
}

cert_check(){
echo "[*] Check certs domain"
DOMAIN_CHECK=$(openssl x509 -in fullchain.pem -noout -text | grep "DNS:" | tr "," "\n" | sed 's/*.//g' | cut -d':' -f2 | head -1)
[ ${DOMAIN} == ${DOMAIN_CHECK} ] || { echo "Wrong cert domain"; exit 1; }

echo "[*] Check certs validity"
diff -s <(echo $(openssl x509 -in fullchain.pem -noout -modulus)) <(echo $(openssl rsa -in privkey.pem -noout -modulus))
[ $? -eq 0 ] || { echo "Certs Missmatch"; exit 1; }
echo ${DOMAIN}
cd ${BASE_DIR}
}

usr_check(){
echo -e "\033[1;97m"
 if [[ -z ${VPS_USER} ]]
 then
    VPS_USER=root
 elif [[ ${VPS_USER} == *['!'@#\$%^\&*()_+1234567890]* ]]
 then
    echo -e "\033[0;31m Not a valid username"; usr_check
 fi
}

pass_check(){
echo -e "\033[1;97m"
if [[ -z ${KEY_NAME} ]]
then
    if [[ -z ${PASS} ]]
    then
        echo -e "\033[0;31m The password cannot be empty \033[1;97m"
        pass_check
    fi
fi
}

ssh_port (){
  if [ -z "${SSH_PORT}" ];
  then
    SSH_PORT=22;
  elif ! [[ "${SSH_PORT}" =~ ^[0-9]+$ ]]
  then
    echo -e "\033[0;31m Not a valid SSH port \033[1;97m"; ssh_port
  fi
}

ssh_connect() {
if [[ -z ${PASS} ]]
 then
   echo "file"
   ssh -o StrictHostKeyChecking=no -p ${SSH_PORT} -i ${KEY_NAME} ${VPS_USER}@${DOMAIN}
 else
   echo "password"
   sshpass -p${PASS} ssh -o StrictHostKeyChecking=no -p ${SSH_PORT} ${VPS_USER}@${DOMAIN}
fi
}

update_vm() {
  echo "[!] Update system and Installing packages"

  sshpass -p${PASS} ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no ${VPS_USER}@${DOMAIN} ' echo "Installing prerequisite packages"
  apt update && apt upgrade -y && apt install python3 -qqq
  apt install gpg gpg-agent wget zip unzip nano secure-delete python3-pip libffi-dev lsb-release jq ca-certificates curl gnupg software-properties-common -qqq
  echo "Installing Docker"
  curl -fsSL https://download.docker.com/linux/debian/gpg | apt-key add -
  add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"
  apt update && apt-cache policy docker-ce && apt install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin docker-compose -qqq
  echo "Install certbot"
  update-alternatives --install /usr/bin/python python /usr/bin/python3 1
  pip3 install --upgrade pip
  pip3 install --upgrade pyopenssl
  pip3 install --upgrade certbot'

}

create_folders() {
  echo "[-] Create Folders"
   sshpass -p${PASS} ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no ${VPS_USER}@${DOMAIN} << EOF
  mkdir -p "${NGINX_CERTS_DIR}"
  mkdir -p "${NGINX_CONFIG_DIR}"
  mkdir -p "${NGINX_INDEX_DIR}"
  mkdir -p "${NGINX_LOG_DIR}"
EOF
}

clone_website(){
  sshpass -p${PASS} ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no ${VPS_USER}@${DOMAIN} << EOF
  cd ${NGINX_INDEX_DIR} && wget --recursive --convert-links --domains=${CLONE_SITE} https://${CLONE_SITE} -xnH
EOF
}

create_certs() {
  if [[ "${PEM_FILE}" == "certbot" ]]
then
  echo "[!] Create certbot certificates"
  sshpass -p${PASS} ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no ${VPS_USER}@${DOMAIN} << EOF
  #ufw allow 80/tcp
  iptables -I INPUT 1 -p tcp --dport 80 -j ACCEPT
  certbot certonly --no-eff-email --agree-tos --register-unsafely-without-email --standalone --domain ${DOMAIN}
  #ufw delete allow 80/tcp

  cp "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" "${NGINX_CERTS_DIR}/fullchain.pem"
  cp "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" "${NGINX_CERTS_DIR}/privkey.pem"
  cp "/etc/letsencrypt/live/${DOMAIN}/chain.pem" "${NGINX_CERTS_DIR}/chain.pem"

  iptables -D INPUT 1
  cat << EOT >> /usr/bin/renewcerts.sh
    #!/bin/bash
    ufw allow 80/tcp
    certbot renew
    ufw delete allow 80/tcp

    cp "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" "${NGINX_CERTS_DIR}/fullchain.pem"
    cp "/etc/letsencrypt/live/${DOMAIN}/privkey.pem"  "${NGINX_CERTS_DIR}/privkey.pem"
    cp "/etc/letsencrypt/live/${DOMAIN}/chain.pem"  "${NGINX_CERTS_DIR}/chain.pem"

    docker restart nginx
EOT
  chmod +x /usr/bin/renewcerts.sh
  echo "43 6 * * * /usr/bin/renewcerts.sh" > /var/spool/cron/crontabs/root

EOF
else if [[ "${PEM_FILE}" == "provided" ]]
    then
      echo "[!] Preparing provided certificates"
      create_certs
      cert_check
    fi
fi
}

os_hardening() {
  echo "[#] Harden kernel"
  sshpass -p${PASS} ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no ${VPS_USER}@${DOMAIN} 'sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && sysctl -w net.ipv6.conf.lo.disable_ipv6=1 && sysctl -p'
}

prepare_cert(){
echo "[*} Zip DOMAIN"
zip -r ${DOMAIN}.zip ${DOMAIN}/
rm -r ${DOMAIN}/
echo "[*} GPG DOMAIN"
gpgpass=$(echo $RANDOM | md5sum | head -c 20; echo;)
touch gpg_sercert_of_${DOMAIN}.txt
echo "${gpgpass}" > gpg_sercert_of_${DOMAIN}.txt
echo -e "\033[0;31mGPG password: ${gpgpass} \033[1;97m"
echo "${gpgpass}" | gpg -c --batch --passphrase-fd 0 ${DOMAIN}.zip
rm ${DOMAIN}.zip
}

copy_required_project_files() {
  echo "[!] Transfer files"
  sshpass -p${PASS} scp -o StrictHostKeyChecking=no -P ${SSH_PORT} Dockerfile docker-compose.yml ${VPS_USER}@${DOMAIN}:${NGINX_CONFIG_DIR}
  sshpass -p${PASS} scp -o StrictHostKeyChecking=no -P ${SSH_PORT} ${DOMAIN}.zip.gpg ${VPS_USER}@${DOMAIN}:~/
  sshpass -p${PASS} ssh -o StrictHostKeyChecking=no -p ${SSH_PORT} ${VPS_USER}@${DOMAIN} << EOF
  echo "${gpgpass}" | gpg --batch --passphrase-fd 0 ${DOMAIN}.zip.gpg
  unzip ${DOMAIN}.zip
  cp ${DOMAIN}/* ${NGINX_CERTS_DIR}/
EOF
}

generate_dh() {
  echo "[!] Create Diffie Hellman"
  sshpass -p${PASS} ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no ${VPS_USER}@${DOMAIN} <<EOF
  [ -e "${NGINX_CERTS_DIR}/dhparam.pem" ] || openssl dhparam -out "${NGINX_CERTS_DIR}/dhparam.pem" 2048
EOF
}

create_default_conf_file() {
  echo "[!] Create nginx configuration file"
  sshpass -p${PASS} ssh -o StrictHostKeyChecking=no -p ${SSH_PORT} ${VPS_USER}@${DOMAIN} << EOF
  cat << EOT >> "${NGINX_CONFIG_DIR}/default.conf"
  user www-data;
  worker_processes auto;
  worker_rlimit_nofile 16384;
  pid /run/nginx.pid;
  include /etc/nginx/modules-enabled/*.conf;
  
  events {
      worker_connections 1024;
  }
  
  http {
    include mime.types;
    default_type application/octet-stream;
    charset utf-8;
    sendfile on;
    sendfile_max_chunk 512k;
    tcp_nodelay on;
    tcp_nopush on;
    keepalive_timeout 3m;
    server_tokens off;
    msie_padding off;
    client_max_body_size 512M;
    client_body_buffer_size 1k;
    client_header_buffer_size 1k;
    large_client_header_buffers 4 4k;
    http2_recv_buffer_size 128k;
    http2_max_concurrent_streams 32;
    server_names_hash_bucket_size 64;
    aio threads;
    aio_write on;
    gzip on;
    gzip_vary on;
    gzip_types *;
    gzip_proxied any;
    gzip_comp_level 5;
    gzip_http_version 1.1;

    server {
        listen      443           ssl http2;
        server_name               ${DOMAIN};
        ssl_certificate           /certificates/fullchain.pem;
        ssl_certificate_key       /certificates/privkey.pem;
        ssl_dhparam               /certificates/dhparam.pem;

        access_log ${NGINX_LOG_DIR}/access.log;
        error_log ${NGINX_LOG_DIR}/error.log;

        location / {
           allow  all;
           root /website;
         index index.html;
          # try_files $uri @fallback;
        }
     # location @fallback {
     #      return 302 https://${DOMAIN}$request_uri;
     #  }

  }
}
EOT

EOF
}

build_container(){
  sshpass -p${PASS} ssh -o StrictHostKeyChecking=no -p ${SSH_PORT} ${VPS_USER}@${DOMAIN} 'docker-compose -f ${NGINX_CONFIG_DIR}/docker-compose.yml up -d
  srm ${NGINX_CONFIG_DIR}/docker-compose.yml ${NGINX_CONFIG_DIR}/Dockerfile
  '
}

main(){
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXEC_DIR=$(pwd)
usr_check
pass_check
ssh_port
ssh_connect
update_vm
create_folders
clone_website
create_certs
prepare_cert
os_hardening
copy_required_project_files
generate_dh
create_default_conf_file
build_container
}

main
